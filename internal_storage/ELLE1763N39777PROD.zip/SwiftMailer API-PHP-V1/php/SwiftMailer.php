<?php
    require_once 'vendor/autoload.php';

    function send_email($apiserver, $apiemail, $apipassword, $companyname, $companyemail, $to, $subject, $message) {
        $transport = (new Swift_SmtpTransport($apiserver, 587))
            ->setUsername($apiemail)
            ->setPassword($apipassword);

        $mailer = new Swift_Mailer($transport);
        $message = (new Swift_Message($subject))
            ->setFrom([$companyemail => $companyname])
            ->setTo($to)
            ->setBody($message, 'text/html');
        $result = $mailer->send($message);
        return $result === 1;
    }
?>