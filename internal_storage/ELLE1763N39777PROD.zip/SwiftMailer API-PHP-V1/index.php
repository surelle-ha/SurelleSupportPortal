<?php

    include "php/SwiftMailer.php";

    if(isset($_POST['sendEmail'])){
        if (send_email('smtp-relay.sendinblue.com', '0110harold@gmail.com', 'Q6rFpKD8nOAUGYJR', 'CompanyName', 'CompanyEmail@gmail.com', $_POST['email'], $_POST['subject'], $_POST['message'])) {
            echo 'Email sent successfully!';
        } else {
            echo 'Failed to send email.';
        }
    }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test Email Sender</title>
</head>
    <body>
        <h1>Test Email Sender</h1>
        <form method="POST">
            <label for="email">Email:</label>
            <input type="email" name="email" required><br>

            <label for="subject">Subject:</label>
            <input type="text" name="subject" required><br>

            <label for="message">Message:</label>
            <textarea name="message" id="message" cols="30" rows="10">

            </textarea><br>

            <input type="submit" name="sendEmail" value="Send Email">
        </form>
    </body>
</html>